import * as THREE from 'three';
import { createSeededRandom } from '../utils/random';

export class SparkleBursts {
  private readonly bursts: {
    points: THREE.Points;
    velocities: Float32Array;
    life: number;
    maxLife: number;
  }[] = [];
  private rng: () => number = createSeededRandom(7);

  constructor(private readonly scene: THREE.Scene) {}

  setRng(rng: () => number): void {
    this.rng = rng;
  }

  spawn(position: THREE.Vector3, color = '#ffd56a', count = 18): void {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);
    for (let i = 0; i < count; i += 1) {
      positions[i * 3] = position.x;
      positions[i * 3 + 1] = position.y;
      positions[i * 3 + 2] = position.z;
      const theta = this.rng() * Math.PI * 2;
      const phi = Math.acos(2 * this.rng() - 1);
      const speed = 1.2 + this.rng() * 2.2;
      velocities[i * 3] = Math.sin(phi) * Math.cos(theta) * speed;
      velocities[i * 3 + 1] = Math.cos(phi) * speed + 1.2;
      velocities[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * speed;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color,
      size: 0.12,
      transparent: true,
      opacity: 0.95,
      depthWrite: false,
      sizeAttenuation: true,
    });
    const points = new THREE.Points(geometry, material);
    this.scene.add(points);
    this.bursts.push({ points, velocities, life: 0, maxLife: 0.75 });
  }

  update(delta: number): void {
    for (let i = this.bursts.length - 1; i >= 0; i -= 1) {
      const burst = this.bursts[i];
      burst.life += delta;
      const attr = burst.points.geometry.getAttribute('position') as THREE.BufferAttribute;
      const arr = attr.array as Float32Array;
      for (let p = 0; p < arr.length; p += 3) {
        arr[p] += burst.velocities[p] * delta;
        arr[p + 1] += burst.velocities[p + 1] * delta;
        arr[p + 2] += burst.velocities[p + 2] * delta;
        burst.velocities[p + 1] -= 4.5 * delta;
      }
      attr.needsUpdate = true;
      const mat = burst.points.material as THREE.PointsMaterial;
      mat.opacity = Math.max(0, 1 - burst.life / burst.maxLife);

      if (burst.life >= burst.maxLife) {
        this.scene.remove(burst.points);
        burst.points.geometry.dispose();
        mat.dispose();
        this.bursts.splice(i, 1);
      }
    }
  }

  dispose(): void {
    for (const burst of this.bursts) {
      this.scene.remove(burst.points);
      burst.points.geometry.dispose();
      (burst.points.material as THREE.Material).dispose();
    }
    this.bursts.length = 0;
  }
}
