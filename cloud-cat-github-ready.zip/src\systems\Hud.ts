export class Hud {
  private readonly scoreValue = this.getElement('#score-value');
  private readonly targetValue = this.getElement('#target-value');
  private readonly heightValue = this.getElement('#height-value');
  private readonly statusLine = this.getElement('#status-line');
  private readonly titleCard = this.getElement('#title-card');
  private readonly resultCard = this.getElement('#result-card');
  private readonly resultTitle = this.getElement('#result-title');
  private readonly resultDetail = this.getElement('#result-detail');

  setTarget(target: number): void {
    this.targetValue.textContent = String(target);
  }

  showTitle(): void {
    this.titleCard.classList.remove('hidden');
    this.resultCard.classList.add('hidden');
  }

  hideTitle(): void {
    this.titleCard.classList.add('hidden');
  }

  showResult(title: string, detail: string): void {
    this.resultTitle.textContent = title;
    this.resultDetail.textContent = detail;
    this.resultCard.classList.remove('hidden');
  }

  hideResult(): void {
    this.resultCard.classList.add('hidden');
  }

  update(score: number, target: number, height: number, complete: boolean, dead: boolean): void {
    this.scoreValue.textContent = String(score);
    this.targetValue.textContent = String(target);
    this.heightValue.textContent = `${Math.max(0, Math.floor(height))}m`;
    if (complete) this.statusLine.textContent = '星冠到手！你是最软的云朵猫～';
    else if (dead) this.statusLine.textContent = '哎呀，掉进云海里了…';
    else if (score === 0) this.statusLine.textContent = '弹到云朵上收集星星吧～';
    else this.statusLine.textContent = `收集到 ${score} 颗星星啦！`;
  }

  flashPickup(): void {
    this.statusLine.animate(
      [
        { transform: 'scale(1)' },
        { transform: 'scale(1.06)' },
        { transform: 'scale(1)' },
      ],
      { duration: 220, easing: 'ease-out' },
    );
  }

  private getElement(selector: string): HTMLElement {
    const element = document.querySelector<HTMLElement>(selector);
    if (!element) throw new Error(`Missing HUD element: ${selector}`);
    return element;
  }
}
