import * as THREE from 'three';

export class StarPickup {
  readonly group = new THREE.Group();
  readonly radius = 0.72;
  active = true;

  private readonly materials: THREE.Material[] = [];
  private readonly geometries: THREE.BufferGeometry[] = [];
  private readonly cameraPos = new THREE.Vector3();
  private cameraRef: THREE.Camera | null = null;
  private restY: number;
  private phase: number;

  constructor(
    readonly index: number,
    position: THREE.Vector3,
  ) {
    this.restY = position.y;
    this.phase = index * 0.9;
    this.group.position.copy(position);

    const starMat = new THREE.MeshStandardMaterial({
      color: '#ffc94a',
      emissive: '#e8920a',
      emissiveIntensity: 1.1,
      roughness: 0.35,
      metalness: 0.1,
    });
    const glowMat = new THREE.MeshBasicMaterial({
      color: '#fff0a8',
      transparent: true,
      opacity: 0.14,
      depthWrite: false,
    });

    const star = new THREE.Mesh(this.createStarGeometry(), starMat);
    star.castShadow = true;
    this.group.add(star);
    this.geometries.push(star.geometry);
    this.materials.push(starMat);

    const glow = new THREE.Mesh(new THREE.SphereGeometry(0.52, 12, 10), glowMat);
    this.group.add(glow);
    this.geometries.push(glow.geometry);
    this.materials.push(glowMat);
  }

  private createStarGeometry(): THREE.BufferGeometry {
    const shape = new THREE.Shape();
    const spikes = 5;
    const outer = 0.48;
    const inner = 0.2;
    for (let i = 0; i < spikes * 2; i += 1) {
      const r = i % 2 === 0 ? outer : inner;
      const a = (i / (spikes * 2)) * Math.PI * 2 - Math.PI / 2;
      const x = Math.cos(a) * r;
      const y = Math.sin(a) * r;
      if (i === 0) shape.moveTo(x, y);
      else shape.lineTo(x, y);
    }
    shape.closePath();
    const geo = new THREE.ExtrudeGeometry(shape, {
      depth: 0.12,
      bevelEnabled: true,
      bevelThickness: 0.04,
      bevelSize: 0.04,
      bevelSegments: 2,
    });
    geo.center();
    return geo;
  }

  update(_delta: number, elapsed: number, camera?: THREE.Camera): void {
    if (!this.active) return;
    if (camera) this.cameraRef = camera;
    this.faceCamera();
    this.group.position.y = this.restY + Math.sin(elapsed * 2.4 + this.phase) * 0.18;
  }

  private faceCamera(): void {
    if (!this.cameraRef) return;
    this.cameraRef.getWorldPosition(this.cameraPos);
    this.group.lookAt(this.cameraPos.x, this.group.position.y, this.cameraPos.z);
  }

  collect(): void {
    this.active = false;
    this.group.visible = false;
  }

  reset(): void {
    this.active = true;
    this.group.visible = true;
    this.stabilizeVisuals();
  }

  stabilizeVisuals(): void {
    this.faceCamera();
    this.group.position.y = this.restY + Math.sin(this.phase) * 0.18;
  }

  dispose(): void {
    for (const geo of this.geometries) geo.dispose();
    for (const mat of this.materials) mat.dispose();
  }
}
