import * as THREE from 'three';
import type { createSeededRandom } from '../utils/random';

type Rng = ReturnType<typeof createSeededRandom>;

type BuildingKind = 'cottage' | 'mushroom' | 'tower' | 'windmill';

const PASTELS = [
  { body: '#ffd6e8', roof: '#ff8fb8', trim: '#fff6fb' },
  { body: '#d9f0ff', roof: '#7eb8e8', trim: '#ffffff' },
  { body: '#fff0c9', roof: '#f0a24a', trim: '#fffaf0' },
  { body: '#e8ddff', roof: '#b89aff', trim: '#f8f4ff' },
  { body: '#d8f5e8', roof: '#6ec9a0', trim: '#f0fff8' },
];

export class CuteBuildings {
  readonly group = new THREE.Group();
  private readonly materials: THREE.Material[] = [];
  private readonly geometries: THREE.BufferGeometry[] = [];
  private readonly floaters: { mesh: THREE.Object3D; baseY: number; phase: number; amp: number }[] = [];

  constructor(rng: Rng) {
    const placements: { x: number; y: number; z: number; scale: number; kind: BuildingKind }[] = [
      // Start cloud surroundings
      { x: -3.4, y: 0.05, z: 1.8, scale: 1.0, kind: 'cottage' },
      { x: 3.6, y: 0.05, z: 1.2, scale: 0.85, kind: 'mushroom' },
      { x: -1.2, y: 0.05, z: 3.2, scale: 0.7, kind: 'tower' },
      // Mid climb
      { x: 5.8, y: 5.6, z: -2.0, scale: 0.9, kind: 'cottage' },
      { x: -4.8, y: 7.2, z: -3.8, scale: 0.8, kind: 'windmill' },
      { x: 2.0, y: 9.4, z: -10.5, scale: 0.75, kind: 'mushroom' },
      { x: -5.5, y: 11.5, z: -5.5, scale: 0.95, kind: 'cottage' },
      { x: 5.5, y: 13.2, z: -12.0, scale: 0.7, kind: 'tower' },
      // Summit
      { x: -3.2, y: 17.4, z: -14.5, scale: 1.05, kind: 'cottage' },
      { x: 1.8, y: 17.6, z: -15.2, scale: 0.8, kind: 'windmill' },
      { x: -0.8, y: 17.5, z: -15.8, scale: 0.65, kind: 'mushroom' },
      // Distant floating houses
      { x: -9, y: 3, z: -2, scale: 1.2, kind: 'cottage' },
      { x: 10, y: 6, z: -8, scale: 1.1, kind: 'tower' },
      { x: -11, y: 12, z: -10, scale: 1.0, kind: 'mushroom' },
      { x: 9, y: 16, z: -16, scale: 1.15, kind: 'cottage' },
    ];

    placements.forEach((p, i) => {
      const palette = PASTELS[Math.floor(rng() * PASTELS.length)];
      const building = this.createBuilding(p.kind, palette, rng);
      building.position.set(p.x, p.y, p.z);
      building.scale.setScalar(p.scale);
      building.rotation.y = rng() * Math.PI * 2;
      this.group.add(building);
      this.floaters.push({
        mesh: building,
        baseY: p.y,
        phase: rng() * Math.PI * 2,
        amp: 0.08 + rng() * 0.1,
      });
      void i;
    });

    // Soft cloud pedestals under buildings (copy list — do not mutate while iterating)
    const buildingsSnapshot = [...this.floaters];
    for (const item of buildingsSnapshot) {
      const pedestal = this.createPedestal(0.9 + rng() * 0.5);
      pedestal.position.copy(item.mesh.position);
      pedestal.position.y -= 0.15;
      pedestal.rotation.y = item.mesh.rotation.y;
      this.group.add(pedestal);
      this.floaters.push({
        mesh: pedestal,
        baseY: pedestal.position.y,
        phase: item.phase,
        amp: item.amp,
      });
    }
  }

  private mat(color: string, opts?: { emissive?: string; roughness?: number }): THREE.MeshStandardMaterial {
    const m = new THREE.MeshStandardMaterial({
      color,
      roughness: opts?.roughness ?? 0.78,
      metalness: 0.02,
      emissive: opts?.emissive ?? '#000000',
      emissiveIntensity: opts?.emissive ? 0.25 : 0,
    });
    this.materials.push(m);
    return m;
  }

  private geo<T extends THREE.BufferGeometry>(g: T): T {
    this.geometries.push(g);
    return g;
  }

  private createBuilding(
    kind: BuildingKind,
    palette: { body: string; roof: string; trim: string },
    rng: Rng,
  ): THREE.Group {
    const g = new THREE.Group();
    if (kind === 'cottage') this.buildCottage(g, palette, rng);
    else if (kind === 'mushroom') this.buildMushroom(g, palette);
    else if (kind === 'tower') this.buildTower(g, palette);
    else this.buildWindmill(g, palette);
    return g;
  }

  private buildCottage(
    g: THREE.Group,
    palette: { body: string; roof: string; trim: string },
    rng: Rng,
  ): void {
    const bodyMat = this.mat(palette.body);
    const roofMat = this.mat(palette.roof, { roughness: 0.55 });
    const trimMat = this.mat(palette.trim);
    const doorMat = this.mat('#8b5a45');
    const windowMat = this.mat('#fff3a8', { emissive: '#f0c040' });

    const body = new THREE.Mesh(this.geo(new THREE.BoxGeometry(1.1, 0.9, 1.0)), bodyMat);
    body.position.y = 0.45;
    body.castShadow = true;
    body.receiveShadow = true;
    g.add(body);

    const roof = new THREE.Mesh(this.geo(new THREE.ConeGeometry(0.95, 0.7, 4)), roofMat);
    roof.position.y = 1.2;
    roof.rotation.y = Math.PI / 4;
    roof.castShadow = true;
    g.add(roof);

    const chimney = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.18, 0.35, 0.18)), trimMat);
    chimney.position.set(0.28, 1.35, 0.1);
    g.add(chimney);

    const door = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.28, 0.42, 0.08)), doorMat);
    door.position.set(0, 0.22, 0.52);
    g.add(door);

    const winL = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.2, 0.2, 0.06)), windowMat);
    winL.position.set(-0.32, 0.55, 0.52);
    g.add(winL);
    const winR = winL.clone();
    winR.position.x = 0.32;
    g.add(winR);

    if (rng() > 0.4) {
      const awning = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.5, 0.06, 0.25)), roofMat);
      awning.position.set(0, 0.48, 0.58);
      awning.rotation.x = 0.25;
      g.add(awning);
    }
  }

  private buildMushroom(g: THREE.Group, _palette: { body: string; roof: string; trim: string }): void {
    const stemMat = this.mat('#fff6ee');
    const capMat = this.mat('#ff7eb6', { roughness: 0.5 });
    const spotMat = this.mat('#fff7fb');
    const doorMat = this.mat('#c9896a');
    const windowMat = this.mat('#fff3a8', { emissive: '#f0c040' });

    const stem = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.28, 0.36, 0.7, 12)), stemMat);
    stem.position.y = 0.35;
    stem.castShadow = true;
    g.add(stem);

    const cap = new THREE.Mesh(this.geo(new THREE.SphereGeometry(0.58, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2)), capMat);
    cap.position.y = 0.62;
    cap.castShadow = true;
    g.add(cap);

    // Slight under-cap rim
    const rim = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.58, 0.48, 0.08, 16)), capMat);
    rim.position.y = 0.64;
    g.add(rim);

    for (let i = 0; i < 5; i += 1) {
      const spot = new THREE.Mesh(this.geo(new THREE.SphereGeometry(0.09, 8, 6)), spotMat);
      const a = (i / 5) * Math.PI * 2 + 0.3;
      const r = 0.22 + (i % 2) * 0.12;
      spot.position.set(Math.cos(a) * r, 0.95 - (i % 2) * 0.08, Math.sin(a) * r);
      spot.scale.y = 0.55;
      g.add(spot);
    }

    const door = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.18, 0.28, 0.06)), doorMat);
    door.position.set(0, 0.2, 0.34);
    g.add(door);

    const win = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.1, 0.1, 0.04)), windowMat);
    win.position.set(0.18, 0.42, 0.3);
    g.add(win);
  }

  private buildTower(g: THREE.Group, palette: { body: string; roof: string; trim: string }): void {
    const bodyMat = this.mat(palette.body);
    const roofMat = this.mat(palette.roof, { roughness: 0.5 });
    const trimMat = this.mat(palette.trim);
    const windowMat = this.mat('#fff3a8', { emissive: '#f0c040' });

    const base = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.32, 0.4, 1.4, 10)), bodyMat);
    base.position.y = 0.7;
    base.castShadow = true;
    g.add(base);

    const balcony = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.42, 0.42, 0.08, 10)), trimMat);
    balcony.position.y = 1.25;
    g.add(balcony);

    const top = new THREE.Mesh(this.geo(new THREE.ConeGeometry(0.4, 0.55, 10)), roofMat);
    top.position.y = 1.7;
    top.castShadow = true;
    g.add(top);

    const flagPole = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.02, 0.02, 0.35, 6)), trimMat);
    flagPole.position.y = 2.1;
    g.add(flagPole);

    const flag = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.28, 0.14, 0.02)), roofMat);
    flag.position.set(0.14, 2.18, 0);
    g.add(flag);

    for (const y of [0.5, 0.9, 1.15]) {
      const win = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.14, 0.16, 0.06)), windowMat);
      win.position.set(0, y, 0.32);
      g.add(win);
    }
  }

  private buildWindmill(g: THREE.Group, palette: { body: string; roof: string; trim: string }): void {
    const bodyMat = this.mat(palette.body);
    const roofMat = this.mat(palette.roof);
    const bladeMat = this.mat(palette.trim, { roughness: 0.6 });
    const hubMat = this.mat('#d4a574');

    const body = new THREE.Mesh(this.geo(new THREE.CylinderGeometry(0.28, 0.42, 1.1, 10)), bodyMat);
    body.position.y = 0.55;
    body.castShadow = true;
    g.add(body);

    const roof = new THREE.Mesh(this.geo(new THREE.ConeGeometry(0.36, 0.4, 10)), roofMat);
    roof.position.y = 1.3;
    g.add(roof);

    const hub = new THREE.Mesh(this.geo(new THREE.SphereGeometry(0.1, 8, 8)), hubMat);
    hub.position.set(0, 1.05, 0.34);
    g.add(hub);

    const blades = new THREE.Group();
    blades.position.copy(hub.position);
    for (let i = 0; i < 4; i += 1) {
      const blade = new THREE.Mesh(this.geo(new THREE.BoxGeometry(0.1, 0.7, 0.04)), bladeMat);
      blade.position.y = 0.35;
      const arm = new THREE.Group();
      arm.rotation.z = (i / 4) * Math.PI * 2;
      arm.add(blade);
      blades.add(arm);
    }
    blades.name = 'blades';
    g.add(blades);
  }

  private createPedestal(radius: number): THREE.Group {
    const g = new THREE.Group();
    const mat = this.mat('#ffffff', { roughness: 0.95 });
    const main = new THREE.Mesh(this.geo(new THREE.SphereGeometry(radius, 14, 10)), mat);
    main.scale.set(1.3, 0.35, 1.1);
    main.castShadow = true;
    main.receiveShadow = true;
    g.add(main);

    const puffMat = this.mat('#fff0f6', { roughness: 0.95 });
    for (let i = 0; i < 5; i += 1) {
      const puff = new THREE.Mesh(this.geo(new THREE.SphereGeometry(radius * 0.35, 10, 8)), puffMat);
      const a = (i / 5) * Math.PI * 2;
      puff.position.set(Math.cos(a) * radius * 0.55, -0.05, Math.sin(a) * radius * 0.5);
      puff.scale.y = 0.55;
      g.add(puff);
    }
    return g;
  }

  update(elapsed: number): void {
    for (const item of this.floaters) {
      item.mesh.position.y = item.baseY + Math.sin(elapsed * 0.7 + item.phase) * item.amp;
    }
    // Spin windmill blades
    this.group.traverse((obj) => {
      if (obj.name === 'blades') obj.rotation.z = elapsed * 0.9;
    });
  }

  stabilizeVisuals(): void {
    for (const item of this.floaters) {
      item.mesh.position.y = item.baseY;
    }
    this.group.traverse((obj) => {
      if (obj.name === 'blades') obj.rotation.z = 0;
    });
  }

  dispose(): void {
    for (const geo of this.geometries) geo.dispose();
    for (const mat of this.materials) mat.dispose();
  }
}
