export {};

declare global {
  interface Window {
    __THREE_GAME_TEST_HOOKS__?: {
      seed: (value: number) => void;
      setState: (name: string) => { state: string };
      setPausedForScreenshot: (paused: boolean) => void;
      setReducedMotion: (enabled: boolean) => void;
      hideDebugUi: (hidden: boolean) => void;
    };
    __THREE_GAME_DIAGNOSTICS__?: {
      frame: number;
      elapsed: number;
      score: number;
      targetScore: number;
      complete: boolean;
      dead?: boolean;
      started?: boolean;
      highestY?: number;
      player: {
        position: { x: number; y: number; z: number };
        speed: number;
        onGround?: boolean;
      };
      renderer: {
        calls: number;
        triangles: number;
        geometries: number;
        textures: number;
      };
      canvas: {
        clientWidth: number;
        clientHeight: number;
        width: number;
        height: number;
        dpr: number;
      };
    };
  }
}
