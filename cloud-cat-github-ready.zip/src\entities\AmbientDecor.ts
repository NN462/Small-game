import * as THREE from 'three';
import type { createSeededRandom } from '../utils/random';

type Rng = ReturnType<typeof createSeededRandom>;

export class AmbientDecor {
  readonly group = new THREE.Group();
  private readonly floats: { mesh: THREE.Mesh; baseY: number; speed: number; phase: number }[] = [];
  private readonly materials: THREE.Material[] = [];
  private readonly geometries: THREE.BufferGeometry[] = [];

  constructor(rng: Rng) {
    const cloudMat = new THREE.MeshStandardMaterial({
      color: '#ffffff',
      roughness: 1,
      metalness: 0,
      transparent: true,
      opacity: 0.55,
    });
    this.materials.push(cloudMat);

    for (let i = 0; i < 16; i += 1) {
      const radius = 1.2 + rng() * 2.4;
      const geo = new THREE.SphereGeometry(radius, 12, 10);
      this.geometries.push(geo);
      const mesh = new THREE.Mesh(geo, cloudMat);
      const angle = rng() * Math.PI * 2;
      const dist = 14 + rng() * 22;
      const y = rng() * 28 - 2;
      mesh.position.set(Math.cos(angle) * dist, y, Math.sin(angle) * dist - 4);
      mesh.scale.set(1.6, 0.55, 1.1);
      this.group.add(mesh);
      this.floats.push({ mesh, baseY: y, speed: 0.15 + rng() * 0.25, phase: rng() * Math.PI * 2 });
    }

    const petalGeo = new THREE.SphereGeometry(0.08, 6, 5);
    this.geometries.push(petalGeo);
    const petalMat = new THREE.MeshStandardMaterial({
      color: '#ffc2d6',
      emissive: '#ff9aba',
      emissiveIntensity: 0.25,
      roughness: 0.7,
    });
    this.materials.push(petalMat);

    for (let i = 0; i < 40; i += 1) {
      const petal = new THREE.Mesh(petalGeo, petalMat);
      petal.position.set((rng() - 0.5) * 30, rng() * 24, (rng() - 0.5) * 30);
      petal.scale.set(1, 0.4, 0.7);
      this.group.add(petal);
      this.floats.push({
        mesh: petal,
        baseY: petal.position.y,
        speed: 0.2 + rng() * 0.35,
        phase: rng() * Math.PI * 2,
      });
    }
  }

  update(elapsed: number): void {
    for (const item of this.floats) {
      item.mesh.position.y = item.baseY + Math.sin(elapsed * item.speed + item.phase) * 0.6;
      item.mesh.rotation.y = elapsed * item.speed * 0.4;
    }
  }

  stabilizeVisuals(): void {
    for (const item of this.floats) {
      item.mesh.position.y = item.baseY;
      item.mesh.rotation.y = 0;
    }
  }

  dispose(): void {
    for (const geo of this.geometries) geo.dispose();
    for (const mat of this.materials) mat.dispose();
  }
}
