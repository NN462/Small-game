import * as THREE from 'three';

export type CloudKind = 'normal' | 'pad' | 'goal';

export class CloudPlatform {
  readonly group = new THREE.Group();
  readonly radius: number;
  readonly kind: CloudKind;
  readonly topY: number;

  private readonly puffs: THREE.Mesh[] = [];
  private readonly materials: THREE.Material[] = [];
  private readonly geometries: THREE.BufferGeometry[] = [];

  constructor(options: {
    x: number;
    z: number;
    y: number;
    radius: number;
    kind?: CloudKind;
    seed: number;
  }) {
    this.kind = options.kind ?? 'normal';
    this.radius = options.radius;
    this.topY = options.y;
    this.group.position.set(options.x, options.y, options.z);

    const baseColor =
      this.kind === 'pad' ? '#ffd0e4' : this.kind === 'goal' ? '#fff6d8' : '#ffffff';
    const puffColor =
      this.kind === 'pad' ? '#ff9ec4' : this.kind === 'goal' ? '#ffe8a3' : '#fff0f6';

    const mainGeo = new THREE.SphereGeometry(options.radius, 20, 14);
    const mainMat = new THREE.MeshStandardMaterial({
      color: baseColor,
      roughness: 0.92,
      metalness: 0,
    });
    const main = new THREE.Mesh(mainGeo, mainMat);
    main.scale.set(1, 0.42, 1);
    main.position.y = -options.radius * 0.28;
    main.castShadow = true;
    main.receiveShadow = true;
    this.group.add(main);
    this.puffs.push(main);
    this.materials.push(mainMat);
    this.geometries.push(mainGeo);

    const puffCount = Math.max(4, Math.round(options.radius * 3));
    for (let i = 0; i < puffCount; i += 1) {
      const angle = (i / puffCount) * Math.PI * 2 + options.seed * 0.7;
      const dist = options.radius * (0.45 + ((options.seed + i) % 5) * 0.08);
      const size = options.radius * (0.28 + ((options.seed * 3 + i) % 4) * 0.05);
      const geo = new THREE.SphereGeometry(size, 12, 10);
      const mat = new THREE.MeshStandardMaterial({
        color: puffColor,
        roughness: 0.95,
        metalness: 0,
      });
      const puff = new THREE.Mesh(geo, mat);
      puff.position.set(
        Math.cos(angle) * dist,
        -options.radius * 0.18 + Math.sin(i * 1.7 + options.seed) * 0.08,
        Math.sin(angle) * dist,
      );
      puff.scale.y = 0.72;
      puff.castShadow = true;
      puff.receiveShadow = true;
      this.group.add(puff);
      this.puffs.push(puff);
      this.materials.push(mat);
      this.geometries.push(geo);
    }

    if (this.kind === 'pad') {
      const capGeo = new THREE.SphereGeometry(options.radius * 0.55, 16, 12);
      const capMat = new THREE.MeshStandardMaterial({
        color: '#ff7eb6',
        emissive: '#c23d78',
        emissiveIntensity: 0.25,
        roughness: 0.55,
        metalness: 0.05,
      });
      const cap = new THREE.Mesh(capGeo, capMat);
      cap.scale.set(1, 0.35, 1);
      cap.position.y = 0.08;
      cap.castShadow = true;
      this.group.add(cap);
      this.materials.push(capMat);
      this.geometries.push(capGeo);
    }

    if (this.kind === 'goal') {
      const ringGeo = new THREE.TorusGeometry(options.radius * 0.72, 0.06, 8, 36);
      const ringMat = new THREE.MeshStandardMaterial({
        color: '#ffd56a',
        emissive: '#f0a24a',
        emissiveIntensity: 0.55,
        roughness: 0.35,
        metalness: 0.2,
      });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = 0.22;
      this.group.add(ring);
      this.materials.push(ringMat);
      this.geometries.push(ringGeo);
    }
  }

  update(_delta: number, elapsed: number): void {
    if (this.kind === 'pad') {
      const s = 1 + Math.sin(elapsed * 3.5) * 0.04;
      this.group.scale.set(s, 1, s);
    } else if (this.kind === 'goal') {
      this.group.rotation.y = elapsed * 0.25;
    } else {
      this.group.position.y = this.topY + Math.sin(elapsed * 0.9 + this.group.position.x) * 0.05;
    }
  }

  /** Visual top surface accounting for idle bob. */
  get currentTopY(): number {
    return this.group.position.y;
  }

  stabilizeVisuals(): void {
    this.group.scale.set(1, 1, 1);
    this.group.position.y = this.topY;
    this.group.rotation.y = this.kind === 'goal' ? 0 : this.group.rotation.y;
  }

  dispose(): void {
    for (const geo of this.geometries) geo.dispose();
    for (const mat of this.materials) mat.dispose();
  }
}
