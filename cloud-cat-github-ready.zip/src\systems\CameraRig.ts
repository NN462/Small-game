import * as THREE from 'three';

export type LookInput = {
  yaw: number;
  pitch: number;
  zoom: number;
};

export class CameraRig {
  private readonly desiredPosition = new THREE.Vector3();
  private readonly lookTarget = new THREE.Vector3();
  private readonly smoothLook = new THREE.Vector3();
  private readonly offset = new THREE.Vector3();

  /** Azimuth around the player. 0 = camera sits behind on +Z. */
  yaw = 0;
  /** Elevation above the player, radians. */
  pitch = 0.52;
  distance = 8.5;

  private readonly minPitch = 0.12;
  private readonly maxPitch = 1.12;
  private readonly minDistance = 4.5;
  private readonly maxDistance = 14;

  constructor(private readonly camera: THREE.PerspectiveCamera) {
    this.applySpherical();
  }

  applyLook(look: LookInput): void {
    this.yaw -= look.yaw;
    this.pitch = THREE.MathUtils.clamp(this.pitch + look.pitch, this.minPitch, this.maxPitch);
    this.distance = THREE.MathUtils.clamp(this.distance + look.zoom, this.minDistance, this.maxDistance);
    this.applySpherical();
  }

  resetLook(): void {
    this.yaw = 0;
    this.pitch = 0.52;
    this.distance = 8.5;
    this.applySpherical();
  }

  /** Ground-plane forward the player should move for "up" on stick/W. */
  getForwardXZ(target: THREE.Vector3): THREE.Vector3 {
    return target.set(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
  }

  getRightXZ(target: THREE.Vector3): THREE.Vector3 {
    return target.set(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
  }

  snapTo(target: THREE.Vector3): void {
    this.applySpherical();
    this.desiredPosition.copy(target).add(this.offset);
    this.camera.position.copy(this.desiredPosition);
    this.smoothLook.set(target.x, target.y + 1.2, target.z);
    this.lookTarget.copy(this.smoothLook);
    this.camera.lookAt(this.lookTarget);
  }

  update(delta: number, target: THREE.Vector3, lag: number): void {
    this.applySpherical();

    const climbBias = Math.max(0, target.y - 2) * 0.05;
    this.desiredPosition.copy(target).add(this.offset);
    this.desiredPosition.y += climbBias;

    const factor = 1 - Math.exp(-delta / Math.max(0.001, lag));
    this.camera.position.lerp(this.desiredPosition, factor);

    this.lookTarget.set(target.x, target.y + 1.25, target.z);
    this.smoothLook.lerp(this.lookTarget, factor);
    this.camera.lookAt(this.smoothLook);
  }

  private applySpherical(): void {
    const horizontal = this.distance * Math.cos(this.pitch);
    this.offset.set(
      Math.sin(this.yaw) * horizontal,
      this.distance * Math.sin(this.pitch),
      Math.cos(this.yaw) * horizontal,
    );
  }
}
