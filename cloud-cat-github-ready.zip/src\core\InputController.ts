import * as THREE from 'three';

type PointerState = {
  active: boolean;
  id: number | null;
  centerX: number;
  centerY: number;
  radius: number;
};

export class InputController {
  private readonly keys = new Set<string>();
  private readonly pointer = new THREE.Vector2();
  private readonly keyVector = new THREE.Vector2();
  private readonly pointerState: PointerState = {
    active: false,
    id: null,
    centerX: 0,
    centerY: 0,
    radius: 1,
  };

  private dashDown = false;
  private looking = false;
  private lookPointerId: number | null = null;
  private lastLookX = 0;
  private lastLookY = 0;
  private yawDelta = 0;
  private pitchDelta = 0;
  private zoomDelta = 0;

  private readonly onKeyDown = (event: KeyboardEvent) => {
    this.keys.add(event.code);
    if (event.code === 'Space' || event.code === 'ShiftLeft' || event.code === 'ShiftRight') {
      this.dashDown = true;
    }
  };

  private readonly onKeyUp = (event: KeyboardEvent) => {
    this.keys.delete(event.code);
    if (event.code === 'Space' || event.code === 'ShiftLeft' || event.code === 'ShiftRight') {
      this.dashDown = false;
    }
  };

  private readonly onStickDown = (event: PointerEvent) => {
    event.preventDefault();
    const rect = this.stick.getBoundingClientRect();
    this.pointerState.active = true;
    this.pointerState.id = event.pointerId;
    this.pointerState.centerX = rect.left + rect.width / 2;
    this.pointerState.centerY = rect.top + rect.height / 2;
    this.pointerState.radius = rect.width * 0.42;
    try {
      this.stick.setPointerCapture(event.pointerId);
    } catch {
      // Synthetic test events do not always have a capturable pointer id.
    }
    this.updatePointer(event.clientX, event.clientY);
  };

  private readonly onStickMove = (event: PointerEvent) => {
    if (!this.pointerState.active || event.pointerId !== this.pointerState.id) return;
    event.preventDefault();
    this.updatePointer(event.clientX, event.clientY);
  };

  private readonly onStickUp = (event: PointerEvent) => {
    if (event.pointerId !== this.pointerState.id) return;
    event.preventDefault();
    this.pointerState.active = false;
    this.pointerState.id = null;
    this.pointer.set(0, 0);
    this.updateKnob();
  };

  private readonly onDashDown = (event: PointerEvent) => {
    event.preventDefault();
    this.dashDown = true;
  };

  private readonly onDashUp = (event: PointerEvent) => {
    event.preventDefault();
    this.dashDown = false;
  };

  private readonly onLookDown = (event: PointerEvent) => {
    // Right-button (or middle) drag orbits the third-person camera.
    if (event.button !== 2 && event.button !== 1) return;
    event.preventDefault();
    this.looking = true;
    this.lookPointerId = event.pointerId;
    this.lastLookX = event.clientX;
    this.lastLookY = event.clientY;
    try {
      this.lookTarget.setPointerCapture(event.pointerId);
    } catch {
      // ignore
    }
  };

  private readonly onLookMove = (event: PointerEvent) => {
    if (!this.looking || event.pointerId !== this.lookPointerId) return;
    event.preventDefault();
    const dx = event.clientX - this.lastLookX;
    const dy = event.clientY - this.lastLookY;
    this.lastLookX = event.clientX;
    this.lastLookY = event.clientY;
    this.yawDelta += dx * 0.0055;
    this.pitchDelta += dy * 0.004;
  };

  private readonly onLookUp = (event: PointerEvent) => {
    if (event.pointerId !== this.lookPointerId) return;
    event.preventDefault();
    this.looking = false;
    this.lookPointerId = null;
  };

  private readonly onContextMenu = (event: Event) => {
    event.preventDefault();
  };

  private readonly onWheel = (event: WheelEvent) => {
    event.preventDefault();
    this.zoomDelta += Math.sign(event.deltaY) * 0.55;
  };

  private readonly onCanvasPointerDown = (event: PointerEvent) => {
    // Touch drag on canvas (not on UI) also orbits — useful on mobile.
    if (event.pointerType !== 'touch') return;
    if ((event.target as HTMLElement | null)?.closest('#touch-controls, #hud, .overlay-card')) {
      return;
    }
    this.onLookDown(event);
  };

  constructor(
    private readonly stick: HTMLElement,
    private readonly knob: HTMLElement,
    private readonly dashButton: HTMLElement,
    private readonly lookTarget: HTMLElement,
  ) {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    this.stick.addEventListener('pointerdown', this.onStickDown);
    this.stick.addEventListener('pointermove', this.onStickMove);
    this.stick.addEventListener('pointerup', this.onStickUp);
    this.stick.addEventListener('pointercancel', this.onStickUp);
    this.dashButton.addEventListener('pointerdown', this.onDashDown);
    this.dashButton.addEventListener('pointerup', this.onDashUp);
    this.dashButton.addEventListener('pointercancel', this.onDashUp);
    this.dashButton.addEventListener('pointerleave', this.onDashUp);

    this.lookTarget.addEventListener('contextmenu', this.onContextMenu);
    this.lookTarget.addEventListener('pointerdown', this.onLookDown);
    this.lookTarget.addEventListener('pointerdown', this.onCanvasPointerDown);
    this.lookTarget.addEventListener('pointermove', this.onLookMove);
    this.lookTarget.addEventListener('pointerup', this.onLookUp);
    this.lookTarget.addEventListener('pointercancel', this.onLookUp);
    this.lookTarget.addEventListener('wheel', this.onWheel, { passive: false });
  }

  readMovement(target: THREE.Vector2): THREE.Vector2 {
    this.keyVector.set(0, 0);
    if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) this.keyVector.x -= 1;
    if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) this.keyVector.x += 1;
    if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) this.keyVector.y -= 1;
    if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) this.keyVector.y += 1;

    target.copy(this.keyVector).add(this.pointer);
    if (target.lengthSq() > 1) target.normalize();
    return target;
  }

  readLook(target: { yaw: number; pitch: number; zoom: number }): void {
    target.yaw = this.yawDelta;
    target.pitch = this.pitchDelta;
    target.zoom = this.zoomDelta;
    this.yawDelta = 0;
    this.pitchDelta = 0;
    this.zoomDelta = 0;
  }

  isDashHeld(): boolean {
    return this.dashDown;
  }

  dispose(): void {
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.stick.removeEventListener('pointerdown', this.onStickDown);
    this.stick.removeEventListener('pointermove', this.onStickMove);
    this.stick.removeEventListener('pointerup', this.onStickUp);
    this.stick.removeEventListener('pointercancel', this.onStickUp);
    this.dashButton.removeEventListener('pointerdown', this.onDashDown);
    this.dashButton.removeEventListener('pointerup', this.onDashUp);
    this.dashButton.removeEventListener('pointercancel', this.onDashUp);
    this.dashButton.removeEventListener('pointerleave', this.onDashUp);

    this.lookTarget.removeEventListener('contextmenu', this.onContextMenu);
    this.lookTarget.removeEventListener('pointerdown', this.onLookDown);
    this.lookTarget.removeEventListener('pointerdown', this.onCanvasPointerDown);
    this.lookTarget.removeEventListener('pointermove', this.onLookMove);
    this.lookTarget.removeEventListener('pointerup', this.onLookUp);
    this.lookTarget.removeEventListener('pointercancel', this.onLookUp);
    this.lookTarget.removeEventListener('wheel', this.onWheel);
  }

  private updatePointer(clientX: number, clientY: number): void {
    const dx = clientX - this.pointerState.centerX;
    const dy = clientY - this.pointerState.centerY;
    this.pointer.set(dx / this.pointerState.radius, dy / this.pointerState.radius);
    if (this.pointer.lengthSq() > 1) this.pointer.normalize();
    this.updateKnob();
  }

  private updateKnob(): void {
    const distance = 38;
    this.knob.style.transform = `translate(calc(-50% + ${this.pointer.x * distance}px), calc(-50% + ${this.pointer.y * distance}px))`;
  }
}
