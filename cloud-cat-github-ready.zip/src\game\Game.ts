import * as THREE from 'three';
import { AmbientDecor } from '../entities/AmbientDecor';
import { CloudCat } from '../entities/CloudCat';
import { CloudPlatform, type CloudKind } from '../entities/CloudPlatform';
import { CuteBuildings } from '../entities/CuteBuildings';
import { SparkleBursts } from '../entities/SparkleBursts';
import { StarPickup } from '../entities/StarPickup';
import { InputController } from '../core/InputController';
import { Loop } from '../core/Loop';
import { createRenderer, resizeRenderer } from '../core/Renderer';
import { AudioSystem } from '../systems/AudioSystem';
import { CameraRig } from '../systems/CameraRig';
import { DebugTools, type DebugTuning } from '../systems/DebugTools';
import { Hud } from '../systems/Hud';
import { createSeededRandom } from '../utils/random';

type PlatformData = {
  x: number;
  z: number;
  y: number;
  radius: number;
  kind: CloudKind;
};

type StarData = {
  x: number;
  y: number;
  z: number;
};

const PLATFORMS: PlatformData[] = [
  { x: 0, z: 0, y: 0, radius: 2.4, kind: 'normal' },
  { x: 2.6, z: -1.2, y: 1.6, radius: 1.35, kind: 'normal' },
  { x: -2.2, z: -2.4, y: 2.8, radius: 1.2, kind: 'normal' },
  { x: 0.4, z: -4.0, y: 4.1, radius: 1.15, kind: 'normal' },
  { x: 3.2, z: -3.2, y: 5.2, radius: 1.1, kind: 'normal' },
  { x: 4.6, z: -5.0, y: 6.4, radius: 1.25, kind: 'pad' },
  { x: 1.2, z: -6.4, y: 7.6, radius: 1.05, kind: 'normal' },
  { x: -1.8, z: -5.6, y: 8.8, radius: 1.15, kind: 'normal' },
  { x: -3.6, z: -7.4, y: 10.0, radius: 1.2, kind: 'normal' },
  { x: -0.2, z: -8.6, y: 11.3, radius: 1.05, kind: 'normal' },
  { x: 2.4, z: -8.0, y: 12.6, radius: 1.15, kind: 'pad' },
  { x: 4.0, z: -10.0, y: 14.0, radius: 1.0, kind: 'normal' },
  { x: 1.0, z: -11.0, y: 15.3, radius: 1.1, kind: 'normal' },
  { x: -2.0, z: -10.2, y: 16.5, radius: 1.05, kind: 'normal' },
  { x: -0.4, z: -12.4, y: 18.0, radius: 1.8, kind: 'goal' },
];

const STARS: StarData[] = [
  { x: 1.8, y: 1.1, z: 0.4 },
  { x: 2.8, y: 2.4, z: -1.6 },
  { x: -2.4, y: 3.6, z: -2.8 },
  { x: 0.2, y: 4.9, z: -4.4 },
  { x: 3.4, y: 6.0, z: -3.4 },
  { x: 4.8, y: 7.6, z: -5.2 },
  { x: 0.8, y: 8.5, z: -6.8 },
  { x: -2.0, y: 9.6, z: -5.8 },
  { x: -3.8, y: 10.8, z: -7.6 },
  { x: 0.0, y: 12.1, z: -8.8 },
  { x: 2.6, y: 13.6, z: -8.2 },
  { x: 4.2, y: 15.0, z: -10.2 },
  { x: 0.8, y: 16.1, z: -11.2 },
  { x: -2.2, y: 17.4, z: -10.4 },
  { x: -0.4, y: 18.9, z: -12.6 },
];

export class Game {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(50, 1, 0.1, 120);
  private readonly input: InputController;
  private readonly player = new CloudCat();
  private readonly platforms: CloudPlatform[] = [];
  private readonly pickups: StarPickup[] = [];
  private readonly audio = new AudioSystem();
  private readonly hud = new Hud();
  private readonly cameraRig = new CameraRig(this.camera);
  private readonly sparkles: SparkleBursts;
  private readonly ambient: AmbientDecor;
  private readonly buildings: CuteBuildings;
  private readonly lookInput = { yaw: 0, pitch: 0, zoom: 0 };
  private readonly camForward = new THREE.Vector3();
  private readonly camRight = new THREE.Vector3();
  private readonly loop = new Loop(
    (delta, elapsed) => this.update(delta, elapsed),
    () => this.render(),
  );

  private readonly tuning: DebugTuning = {
    speed: 5.0,
    airControl: 0.82,
    acceleration: 11,
    gravity: 17.5,
    bounceVelocity: 10.4,
    padBounceVelocity: 14.2,
    dashMultiplier: 1.45,
    dashDuration: 0.16,
    maxFallSpeed: 14,
    turnSmoothing: 10,
    cameraLag: 0.22,
    exposure: 1.08,
    maxDpr: 2,
  };

  private readonly debugTools: DebugTools;
  private readonly spawn = new THREE.Vector3(0, 0, 0);
  private frame = 0;
  private score = 0;
  private elapsed = 0;
  private complete = false;
  private dead = false;
  private started = false;
  private highestY = 0;
  private rng = createSeededRandom(42);
  private pausedForScreenshot = false;
  private reducedMotion = false;
  private platformsGroup = new THREE.Group();
  private skyMesh: THREE.Mesh | null = null;

  constructor(private readonly canvas: HTMLCanvasElement) {
    this.renderer = createRenderer(canvas);
    this.renderer.toneMappingExposure = this.tuning.exposure;
    this.sparkles = new SparkleBursts(this.scene);
    this.ambient = new AmbientDecor(this.rng);
    this.buildings = new CuteBuildings(this.rng);

    const stick = this.getElement('#touch-stick');
    const knob = this.getElement('#touch-knob');
    const dashButton = this.getElement('#dash-button');
    this.input = new InputController(stick, knob, dashButton, canvas);

    this.debugTools = new DebugTools(this.tuning, () => {
      this.renderer.toneMappingExposure = this.tuning.exposure;
      resizeRenderer(this.renderer, this.camera, this.tuning.maxDpr);
    });

    this.createScene();
    this.hud.setTarget(this.pickups.length);
    this.cameraRig.snapTo(this.player.group.position);
    resizeRenderer(this.renderer, this.camera, this.tuning.maxDpr);
    this.installTestHooks();
    this.publishDiagnostics();
    this.hud.showTitle();

    this.getElement('#start-button').addEventListener('click', () => this.beginRun());
    this.getElement('#retry-button').addEventListener('click', () => this.restartRun());
  }

  start(): void {
    this.loop.start();
  }

  dispose(): void {
    this.loop.stop();
    this.input.dispose();
    this.audio.dispose();
    this.debugTools.dispose();
    this.sparkles.dispose();
    this.ambient.dispose();
    this.buildings.dispose();
    for (const platform of this.platforms) platform.dispose();
    for (const pickup of this.pickups) pickup.dispose();
    this.player.dispose();
    this.skyMesh?.geometry.dispose();
    ((this.skyMesh?.material as THREE.Material | undefined) ?? null)?.dispose();
    this.renderer.dispose();
    window.__THREE_GAME_DIAGNOSTICS__ = undefined;
    window.__THREE_GAME_TEST_HOOKS__ = undefined;
  }

  private beginRun(): void {
    this.started = true;
    this.dead = false;
    this.complete = false;
    this.hud.hideTitle();
    this.hud.hideResult();
    this.resetRun();
  }

  private restartRun(): void {
    this.started = true;
    this.dead = false;
    this.complete = false;
    this.hud.hideTitle();
    this.hud.hideResult();
    this.resetRun();
  }

  private update(delta: number, elapsed: number): void {
    this.frame += 1;
    if (this.pausedForScreenshot) {
      this.publishDiagnostics();
      return;
    }

    resizeRenderer(this.renderer, this.camera, this.tuning.maxDpr);
    const animDelta = this.reducedMotion ? 0 : delta;
    const animElapsed = this.reducedMotion ? 0 : elapsed;

    if (this.started && !this.dead && !this.complete) {
      this.elapsed += delta;
    }

    if (!this.reducedMotion) {
      for (const platform of this.platforms) platform.update(animDelta, animElapsed);
      for (const pickup of this.pickups) pickup.update(animDelta, animElapsed, this.camera);
      this.ambient.update(animElapsed);
      this.buildings.update(animElapsed);
    }

    this.input.readLook(this.lookInput);
    this.cameraRig.applyLook(this.lookInput);
    this.cameraRig.getForwardXZ(this.camForward);
    this.cameraRig.getRightXZ(this.camRight);

    if (this.started && !this.dead && !this.complete) {
      const priorY = this.player.group.position.y;
      this.player.update(delta, elapsed, this.input, this.tuning, this.camForward, this.camRight);

      const landing = this.player.landOnTop(
        priorY,
        this.platforms.map((p) => ({
          x: p.group.position.x,
          z: p.group.position.z,
          y: p.currentTopY,
          radius: p.radius * 0.92,
          isPad: p.kind === 'pad',
        })),
      );

      if (landing) {
        const strength = landing.isPad ? this.tuning.padBounceVelocity : this.tuning.bounceVelocity;
        this.player.bounce(strength);
        this.audio.bounce(landing.isPad);
        this.sparkles.spawn(
          this.player.group.position.clone().setY(landing.y + 0.2),
          landing.isPad ? '#ff9ec4' : '#ffffff',
          landing.isPad ? 14 : 6,
        );
      }

      const collected = this.collectStars();
      this.score += collected.length;
      for (const star of collected) {
        this.audio.pickup(star.index);
        this.hud.flashPickup();
        this.sparkles.spawn(star.group.position.clone(), '#ffd56a', 16);
      }

      if (this.player.group.position.y > this.highestY) {
        this.highestY = this.player.group.position.y;
      }

      if (this.score >= this.pickups.length && this.pickups.length > 0) {
        this.complete = true;
        this.audio.win();
        this.sparkles.spawn(this.player.group.position.clone().setY(this.player.group.position.y + 1), '#ffd56a', 28);
        this.hud.showResult('星冠到手！', `收集了 ${this.score} 颗星星 · 最高 ${Math.floor(this.highestY)}m`);
      } else if (this.player.group.position.y < -6) {
        this.dead = true;
        this.audio.fail();
        this.hud.showResult('再试一次～', `收集了 ${this.score} 颗星星 · 最高 ${Math.floor(this.highestY)}m`);
      }
    }

    this.sparkles.update(delta);
    this.cameraRig.update(delta, this.player.group.position, this.tuning.cameraLag);
    this.hud.update(
      this.score,
      this.pickups.length,
      this.highestY,
      this.complete,
      this.dead,
    );
    this.publishDiagnostics();
  }

  private collectStars(): StarPickup[] {
    const collected: StarPickup[] = [];
    const playerPos = this.player.group.position;
    for (const pickup of this.pickups) {
      if (!pickup.active) continue;
      const dx = playerPos.x - pickup.group.position.x;
      const dy = playerPos.y + 0.55 - pickup.group.position.y;
      const dz = playerPos.z - pickup.group.position.z;
      const r = 0.55 + pickup.radius;
      if (dx * dx + dy * dy + dz * dz <= r * r) {
        pickup.collect();
        collected.push(pickup);
      }
    }
    return collected;
  }

  private render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  private createScene(): void {
    this.scene.background = new THREE.Color('#c9e7ff');
    this.scene.fog = new THREE.Fog('#f7c9d9', 18, 55);

    this.createSkyDome();

    const hemisphere = new THREE.HemisphereLight('#ffe8f0', '#b8d9ff', 1.55);
    this.scene.add(hemisphere);

    const sun = new THREE.DirectionalLight('#fff4d6', 2.2);
    sun.position.set(-6, 14, 8);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.near = 0.5;
    sun.shadow.camera.far = 50;
    sun.shadow.camera.left = -16;
    sun.shadow.camera.right = 16;
    sun.shadow.camera.top = 24;
    sun.shadow.camera.bottom = -8;
    this.scene.add(sun);

    const fill = new THREE.DirectionalLight('#ffd6e8', 0.55);
    fill.position.set(8, 6, -10);
    this.scene.add(fill);

    this.scene.add(this.ambient.group);
    this.scene.add(this.buildings.group);
    this.createWorld();
    this.scene.add(this.player.group);
  }

  private createSkyDome(): void {
    const geometry = new THREE.SphereGeometry(70, 32, 24);
    const material = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        topColor: { value: new THREE.Color('#a8d8ff') },
        midColor: { value: new THREE.Color('#f7c9d9') },
        bottomColor: { value: new THREE.Color('#ffe8c8') },
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldPosition = worldPosition.xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 topColor;
        uniform vec3 midColor;
        uniform vec3 bottomColor;
        varying vec3 vWorldPosition;
        void main() {
          float h = normalize(vWorldPosition).y;
          vec3 color = mix(bottomColor, midColor, smoothstep(-0.25, 0.15, h));
          color = mix(color, topColor, smoothstep(0.1, 0.7, h));
          gl_FragColor = vec4(color, 1.0);
        }
      `,
    });
    this.skyMesh = new THREE.Mesh(geometry, material);
    this.scene.add(this.skyMesh);
  }

  private createWorld(): void {
    this.platformsGroup.clear();
    for (let i = 0; i < PLATFORMS.length; i += 1) {
      const data = PLATFORMS[i];
      const platform = new CloudPlatform({
        x: data.x,
        z: data.z,
        y: data.y,
        radius: data.radius,
        kind: data.kind,
        seed: i,
      });
      this.platforms.push(platform);
      this.platformsGroup.add(platform.group);
    }
    this.scene.add(this.platformsGroup);

    for (let i = 0; i < STARS.length; i += 1) {
      const data = STARS[i];
      const star = new StarPickup(i, new THREE.Vector3(data.x, data.y, data.z));
      this.pickups.push(star);
      this.scene.add(star.group);
    }
  }

  private installTestHooks(): void {
    window.__THREE_GAME_TEST_HOOKS__ = {
      seed: (value: number) => {
        this.rng = createSeededRandom(value);
        this.sparkles.setRng(this.rng);
      },
      setState: (name: string) => {
        if (name !== 'title' && name !== 'active-play' && name !== 'complete' && name !== 'fail') {
          throw new Error(`Unknown test state: ${name}`);
        }
        this.resetRun();
        this.started = name !== 'title';
        this.hud.hideTitle();
        this.hud.hideResult();
        if (name === 'title') {
          this.started = false;
          this.hud.showTitle();
        }
        if (name === 'complete') {
          this.completeRun();
        }
        if (name === 'fail') {
          this.dead = true;
          this.player.group.position.y = -8;
          this.hud.showResult('再试一次～', `收集了 ${this.score} 颗星星 · 最高 ${Math.floor(this.highestY)}m`);
        }
        this.render();
        this.publishDiagnostics();
        return { state: name };
      },
      setPausedForScreenshot: (paused: boolean) => {
        this.pausedForScreenshot = paused;
      },
      setReducedMotion: (enabled: boolean) => {
        this.reducedMotion = enabled;
        if (enabled) {
          this.player.stabilizeVisuals();
          for (const platform of this.platforms) platform.stabilizeVisuals();
          for (const pickup of this.pickups) pickup.stabilizeVisuals();
          this.ambient.stabilizeVisuals();
          this.buildings.stabilizeVisuals();
        }
        this.render();
        this.publishDiagnostics();
      },
      hideDebugUi: (hidden: boolean) => {
        this.debugTools.setHidden(hidden);
      },
    };
  }

  private resetRun(): void {
    this.score = 0;
    this.elapsed = 0;
    this.complete = false;
    this.dead = false;
    this.highestY = 0;
    this.player.reset(this.spawn);
    for (const pickup of this.pickups) pickup.reset();
    for (const platform of this.platforms) platform.stabilizeVisuals();
    this.cameraRig.resetLook();
    this.cameraRig.snapTo(this.player.group.position);
    for (const pickup of this.pickups) {
      pickup.update(0, 0, this.camera);
    }
    this.hud.setTarget(this.pickups.length);
    this.hud.update(this.score, this.pickups.length, this.highestY, false, false);
  }

  private completeRun(): void {
    for (const pickup of this.pickups) {
      if (pickup.active) pickup.collect();
    }
    this.score = this.pickups.length;
    this.complete = true;
    this.highestY = 18;
    this.hud.update(this.score, this.pickups.length, this.highestY, true, false);
    this.hud.showResult('星冠到手！', `收集了 ${this.score} 颗星星 · 最高 ${Math.floor(this.highestY)}m`);
  }

  private publishDiagnostics(): void {
    const info = this.renderer.info;
    window.__THREE_GAME_DIAGNOSTICS__ = {
      frame: this.frame,
      elapsed: this.elapsed,
      score: this.score,
      targetScore: this.pickups.length,
      complete: this.complete,
      dead: this.dead,
      started: this.started,
      highestY: this.highestY,
      player: {
        position: {
          x: this.player.group.position.x,
          y: this.player.group.position.y,
          z: this.player.group.position.z,
        },
        speed: this.player.velocity.length(),
        onGround: this.player.onGround,
      },
      renderer: {
        calls: info.render.calls,
        triangles: info.render.triangles,
        geometries: info.memory.geometries,
        textures: info.memory.textures,
      },
      canvas: {
        clientWidth: this.canvas.clientWidth,
        clientHeight: this.canvas.clientHeight,
        width: this.canvas.width,
        height: this.canvas.height,
        dpr: Math.min(window.devicePixelRatio || 1, this.tuning.maxDpr),
      },
    };
  }

  private getElement(selector: string): HTMLElement {
    const element = document.querySelector<HTMLElement>(selector);
    if (!element) throw new Error(`Missing element: ${selector}`);
    return element;
  }
}
