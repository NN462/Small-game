import * as THREE from 'three';
import type { InputController } from '../core/InputController';

export type PlayerTuning = {
  speed: number;
  airControl: number;
  acceleration: number;
  gravity: number;
  bounceVelocity: number;
  padBounceVelocity: number;
  dashMultiplier: number;
  dashDuration: number;
  maxFallSpeed: number;
  turnSmoothing: number;
};

export class CloudCat {
  readonly group = new THREE.Group();
  readonly velocity = new THREE.Vector3();
  onGround = false;
  lastBounceWasPad = false;

  private readonly move = new THREE.Vector2();
  private readonly targetVelocity = new THREE.Vector3();
  private readonly camForward = new THREE.Vector3();
  private readonly camRight = new THREE.Vector3();
  private squash = 1;
  private stretchTarget = 1;
  private dashTimer = 0;
  private facing = 0;
  private bob = 0;

  private readonly bodyMaterial = new THREE.MeshStandardMaterial({
    color: '#ffb07a',
    roughness: 0.72,
    metalness: 0.02,
  });
  private readonly creamMaterial = new THREE.MeshStandardMaterial({
    color: '#fff4e4',
    roughness: 0.78,
    metalness: 0,
  });
  private readonly blushMaterial = new THREE.MeshStandardMaterial({
    color: '#ff9aa8',
    roughness: 0.85,
    metalness: 0,
  });
  private readonly darkMaterial = new THREE.MeshStandardMaterial({
    color: '#4a3340',
    roughness: 0.55,
    metalness: 0.05,
  });
  private readonly bodyGeometry = new THREE.SphereGeometry(0.55, 24, 18);
  private readonly headGeometry = new THREE.SphereGeometry(0.38, 20, 16);
  private readonly earGeometry = new THREE.ConeGeometry(0.16, 0.28, 4);
  private readonly muzzleGeometry = new THREE.SphereGeometry(0.16, 12, 10);
  private readonly blushGeometry = new THREE.SphereGeometry(0.09, 10, 8);
  private readonly eyeGeometry = new THREE.SphereGeometry(0.075, 12, 10);
  private readonly noseGeometry = new THREE.SphereGeometry(0.045, 8, 8);
  private readonly tailGeometry = new THREE.CapsuleGeometry(0.07, 0.28, 4, 8);
  private readonly footGeometry = new THREE.SphereGeometry(0.13, 10, 8);

  private readonly visual = new THREE.Group();
  private readonly tail = new THREE.Group();
  private readonly shadow: THREE.Mesh;
  private readonly shadowMaterial: THREE.MeshBasicMaterial;

  constructor() {
    const body = new THREE.Mesh(this.bodyGeometry, this.bodyMaterial);
    body.castShadow = true;
    body.receiveShadow = true;
    body.position.y = 0.52;
    body.scale.set(1.05, 0.9, 1);
    this.visual.add(body);

    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12), this.creamMaterial);
    belly.position.set(0, 0.42, 0.22);
    belly.scale.set(1, 0.85, 0.7);
    this.visual.add(belly);

    const head = new THREE.Mesh(this.headGeometry, this.bodyMaterial);
    head.castShadow = true;
    head.position.set(0, 1.05, 0.08);
    this.visual.add(head);

    const muzzle = new THREE.Mesh(this.muzzleGeometry, this.creamMaterial);
    muzzle.position.set(0, 0.98, 0.32);
    muzzle.scale.set(1.2, 0.85, 0.8);
    this.visual.add(muzzle);

    const earL = new THREE.Mesh(this.earGeometry, this.bodyMaterial);
    earL.position.set(-0.22, 1.35, 0.02);
    earL.rotation.z = 0.35;
    earL.rotation.x = -0.15;
    earL.castShadow = true;
    this.visual.add(earL);

    const earR = earL.clone();
    earR.position.x = 0.22;
    earR.rotation.z = -0.35;
    this.visual.add(earR);

    const earInnerL = new THREE.Mesh(this.earGeometry, this.blushMaterial);
    earInnerL.scale.set(0.55, 0.55, 0.55);
    earInnerL.position.set(-0.22, 1.32, 0.08);
    earInnerL.rotation.z = 0.35;
    this.visual.add(earInnerL);

    const earInnerR = earInnerL.clone();
    earInnerR.position.x = 0.22;
    earInnerR.rotation.z = -0.35;
    this.visual.add(earInnerR);

    const eyeL = new THREE.Mesh(this.eyeGeometry, this.darkMaterial);
    eyeL.position.set(-0.15, 1.12, 0.38);
    eyeL.scale.set(1, 1.2, 0.7);
    this.visual.add(eyeL);

    const eyeR = eyeL.clone();
    eyeR.position.x = 0.15;
    this.visual.add(eyeR);

    const nose = new THREE.Mesh(this.noseGeometry, this.blushMaterial);
    nose.position.set(0, 1.0, 0.42);
    this.visual.add(nose);

    const blushL = new THREE.Mesh(this.blushGeometry, this.blushMaterial);
    blushL.position.set(-0.28, 0.98, 0.22);
    blushL.scale.set(1.2, 0.7, 0.5);
    this.visual.add(blushL);

    const blushR = blushL.clone();
    blushR.position.x = 0.28;
    this.visual.add(blushR);

    const footL = new THREE.Mesh(this.footGeometry, this.creamMaterial);
    footL.position.set(-0.22, 0.12, 0.18);
    footL.scale.set(1.1, 0.7, 1.3);
    footL.castShadow = true;
    this.visual.add(footL);

    const footR = footL.clone();
    footR.position.x = 0.22;
    this.visual.add(footR);

    this.tail.position.set(0, 0.55, -0.48);
    const tailMesh = new THREE.Mesh(this.tailGeometry, this.bodyMaterial);
    tailMesh.position.y = 0.18;
    tailMesh.rotation.x = 0.9;
    tailMesh.castShadow = true;
    this.tail.add(tailMesh);
    this.visual.add(this.tail);

    const shadowGeo = new THREE.CircleGeometry(0.55, 24);
    this.shadowMaterial = new THREE.MeshBasicMaterial({
      color: '#c9a0b0',
      transparent: true,
      opacity: 0.22,
      depthWrite: false,
    });
    const shadow = new THREE.Mesh(shadowGeo, this.shadowMaterial);
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.02;
    this.shadow = shadow;
    this.group.add(shadow);

    this.group.add(this.visual);
  }

  update(
    delta: number,
    elapsed: number,
    input: InputController,
    tuning: PlayerTuning,
    cameraForward?: THREE.Vector3,
    cameraRight?: THREE.Vector3,
  ): void {
    input.readMovement(this.move);
    if (input.isDashHeld() && this.dashTimer <= 0) {
      this.dashTimer = tuning.dashDuration;
    }
    this.dashTimer = Math.max(0, this.dashTimer - delta);
    const dash = this.dashTimer > 0 ? tuning.dashMultiplier : 1;

    const control = this.onGround ? 1 : tuning.airControl;
    // stick.y / W is -1 forward in input space; map through camera basis.
    if (cameraForward && cameraRight) {
      this.camForward.copy(cameraForward);
      this.camRight.copy(cameraRight);
      this.targetVelocity
        .set(0, 0, 0)
        .addScaledVector(this.camRight, this.move.x)
        .addScaledVector(this.camForward, -this.move.y)
        .multiplyScalar(tuning.speed * dash * control);
    } else {
      this.targetVelocity.set(this.move.x, 0, this.move.y).multiplyScalar(tuning.speed * dash * control);
    }

    const smoothing = 1 - Math.exp(-tuning.acceleration * delta);
    this.velocity.x = THREE.MathUtils.lerp(this.velocity.x, this.targetVelocity.x, smoothing);
    this.velocity.z = THREE.MathUtils.lerp(this.velocity.z, this.targetVelocity.z, smoothing);
    this.velocity.y = Math.max(this.velocity.y - tuning.gravity * delta, -tuning.maxFallSpeed);

    this.group.position.addScaledVector(this.velocity, delta);

    if (this.velocity.lengthSq() > 0.04) {
      const targetFacing = Math.atan2(this.velocity.x, this.velocity.z);
      let diff = targetFacing - this.facing;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.facing += diff * Math.min(1, tuning.turnSmoothing * delta);
      this.visual.rotation.y = this.facing;
    }

    this.bob = elapsed * 10;
    if (this.onGround) {
      this.stretchTarget = 0.92;
      this.visual.position.y = Math.sin(this.bob) * 0.03;
    } else {
      this.stretchTarget = THREE.MathUtils.clamp(1 + this.velocity.y * 0.045, 0.85, 1.25);
      this.visual.position.y = 0;
    }

    this.squash = THREE.MathUtils.lerp(this.squash, this.stretchTarget, 1 - Math.exp(-12 * delta));
    this.visual.scale.set(1 / Math.sqrt(this.squash), this.squash, 1 / Math.sqrt(this.squash));

    const airHeight = Math.max(0, this.velocity.y > 0 ? this.velocity.y * 0.08 : 0.05);
    const shadowScale = THREE.MathUtils.clamp(1 - airHeight * 0.35, 0.55, 1);
    this.shadow.scale.setScalar(shadowScale);
    this.shadowMaterial.opacity = 0.22 * shadowScale;

    this.tail.rotation.z = Math.sin(elapsed * 4) * 0.25 + this.velocity.x * 0.04;
  }

  bounce(strength: number): void {
    this.velocity.y = strength;
    this.onGround = false;
    this.squash = 0.72;
  }

  landOnTop(
    priorY: number,
    platforms: { x: number; z: number; y: number; radius: number; isPad: boolean }[],
  ): { y: number; isPad: boolean } | null {
    if (this.velocity.y > 0.15) {
      this.onGround = false;
      return null;
    }

    const px = this.group.position.x;
    const pz = this.group.position.z;
    let best: { y: number; isPad: boolean } | null = null;

    for (const p of platforms) {
      const dx = px - p.x;
      const dz = pz - p.z;
      if (dx * dx + dz * dz > p.radius * p.radius) continue;
      if (priorY < p.y - 0.12) continue;
      if (this.group.position.y > p.y + 0.18) continue;
      if (!best || p.y > best.y) best = { y: p.y, isPad: p.isPad };
    }

    if (!best) {
      this.onGround = false;
      return null;
    }

    this.group.position.y = best.y;
    this.lastBounceWasPad = best.isPad;
    this.onGround = true;
    this.squash = 0.7;
    return best;
  }

  reset(spawn: THREE.Vector3): void {
    this.group.position.copy(spawn);
    this.group.rotation.set(0, 0, 0);
    this.visual.rotation.set(0, 0, 0);
    this.visual.position.set(0, 0, 0);
    this.visual.scale.set(1, 1, 1);
    this.velocity.set(0, 0, 0);
    this.move.set(0, 0);
    this.targetVelocity.set(0, 0, 0);
    this.squash = 1;
    this.dashTimer = 0;
    this.facing = 0;
    this.onGround = true;
    this.lastBounceWasPad = false;
    this.stabilizeVisuals();
  }

  stabilizeVisuals(): void {
    this.visual.scale.set(1, 1, 1);
    this.visual.position.y = 0;
    this.tail.rotation.z = 0;
  }

  dispose(): void {
    for (const geo of [
      this.bodyGeometry,
      this.headGeometry,
      this.earGeometry,
      this.muzzleGeometry,
      this.blushGeometry,
      this.eyeGeometry,
      this.noseGeometry,
      this.tailGeometry,
      this.footGeometry,
      this.shadow.geometry,
    ]) {
      geo.dispose();
    }
    // Shared clones used the same geometries; dispose materials once.
    for (const mat of [
      this.bodyMaterial,
      this.creamMaterial,
      this.blushMaterial,
      this.darkMaterial,
      this.shadowMaterial,
    ]) {
      mat.dispose();
    }
  }
}
