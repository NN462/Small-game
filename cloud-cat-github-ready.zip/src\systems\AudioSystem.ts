export class AudioSystem {
  private context: AudioContext | null = null;
  private unlocked = false;

  constructor() {
    const unlock = () => {
      void this.unlock();
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
  }

  async unlock(): Promise<void> {
    if (this.unlocked) return;
    const AudioContextClass =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;
    this.context = new AudioContextClass();
    await this.context.resume();
    this.unlocked = true;
  }

  pickup(index: number): void {
    if (!this.context || this.context.state !== 'running') return;
    const now = this.context.currentTime;
    const notes = [523.25, 659.25, 783.99, 987.77, 1174.66];
    const freq = notes[index % notes.length];
    this.blip(freq, freq * 1.35, 0.16, 'triangle', 0.07, now);
    this.blip(freq * 2, freq * 2.2, 0.08, 'sine', 0.035, now + 0.04);
  }

  bounce(isPad: boolean): void {
    if (!this.context || this.context.state !== 'running') return;
    const now = this.context.currentTime;
    if (isPad) {
      this.blip(392, 784, 0.18, 'sine', 0.06, now);
      this.blip(523, 1046, 0.12, 'triangle', 0.04, now + 0.03);
    } else {
      this.blip(280, 420, 0.08, 'sine', 0.035, now);
    }
  }

  fail(): void {
    if (!this.context || this.context.state !== 'running') return;
    const now = this.context.currentTime;
    this.blip(392, 196, 0.28, 'triangle', 0.05, now);
    this.blip(330, 165, 0.32, 'sine', 0.03, now + 0.08);
  }

  win(): void {
    if (!this.context || this.context.state !== 'running') return;
    const now = this.context.currentTime;
    const seq = [523.25, 659.25, 783.99, 1046.5];
    seq.forEach((f, i) => {
      this.blip(f, f, 0.18, 'triangle', 0.055, now + i * 0.09);
    });
  }

  private blip(
    startFreq: number,
    endFreq: number,
    duration: number,
    type: OscillatorType,
    volume: number,
    when: number,
  ): void {
    if (!this.context) return;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(startFreq, when);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(40, endFreq), when + duration);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(volume, when + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration);
    oscillator.connect(gain).connect(this.context.destination);
    oscillator.start(when);
    oscillator.stop(when + duration + 0.02);
  }

  dispose(): void {
    void this.context?.close();
    this.context = null;
  }
}
